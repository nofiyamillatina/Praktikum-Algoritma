# konstanta pi
phi = 3.14

# menghitung luas lingkaran
def luas_lingkaran(jari_jari):
  Llingkaran = phi * jari_jari **2
  return Llingkaran

# menghitung luas persegi
def luas_persegi(sisi):
  Lpersegi = sisi * sisi
  return Lpersegi